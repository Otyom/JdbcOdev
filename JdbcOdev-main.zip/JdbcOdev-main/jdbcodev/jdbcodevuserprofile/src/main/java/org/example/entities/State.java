package org.example.entities;

public enum State {
    Aktive,İnaktive,Deleted;
}
